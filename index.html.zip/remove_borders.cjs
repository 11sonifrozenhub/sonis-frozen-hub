const fs = require('fs');
const path = require('path');

const walk = (dir) => {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach((file) => {
    file = path.join(dir, file);
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) {
      results = results.concat(walk(file));
    } else if (file.endsWith('.tsx') || file.endsWith('.ts')) {
      results.push(file);
    }
  });
  return results;
};

const files = walk('./src');

files.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  
  content = content.replace(/border-[tblr] border-\[#[a-fA-F0-9]{6}\]/g, '');
  content = content.replace(/border border-\[#[a-fA-F0-9]{6}\]/g, '');
  content = content.replace(/border-\[#[a-fA-F0-9]{6}\]/g, '');
  
  fs.writeFileSync(file, content);
});

console.log('Removed borders');
