import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Menu, X, ShoppingCart, User, Search, MapPin, Phone } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { categories, products } from '../data';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

export function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { totalItems } = useCart();
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products?search=${encodeURIComponent(searchQuery.trim())}`);
      setSearchQuery('');
      setIsMenuOpen(false);
    }
  };

  const liveSearchResults = searchQuery.trim() === '' ? [] : products.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    p.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.category.toLowerCase().includes(searchQuery.toLowerCase())
  ).slice(0, 5);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Products', path: '/products' },
    { name: 'Offers', path: '/products?filter=offers' },
    { name: 'Track Order', path: '/track-order' },
    { name: 'About Us', path: '/#about' },
    { name: 'Contact Us', path: '/#contact' },
  ];

  return (
    <>
      <header className="h-16  flex items-center justify-between px-4 sm:px-8 bg-[#991b1b] flex-none sticky top-0 z-50">
        <div className="flex items-center gap-4 sm:gap-6">
          <button 
            onClick={() => setIsMenuOpen(true)}
            className="w-6 h-5 sm:w-8 sm:h-6 flex flex-col justify-between cursor-pointer group focus:outline-none"
          >
            <span className="h-[2px] w-full bg-[#7f1d1d] transition-all group-hover:bg-[#7f1d1d]/70"></span>
            <span className="h-[2px] w-2/3 bg-[#7f1d1d] transition-all group-hover:w-full group-hover:bg-[#7f1d1d]/70"></span>
            <span className="h-[2px] w-full bg-[#7f1d1d] transition-all group-hover:bg-[#7f1d1d]/70"></span>
          </button>
          <Link to="/" className="flex-shrink-0 flex items-center">
            <h1 className="text-lg sm:text-xl tracking-[0.2em] font-bold font-serif uppercase">
              SONI'S <span className="hidden sm:inline">FROZEN HUB</span>
            </h1>
          </Link>
        </div>
        
        <div className="hidden md:flex flex-1 max-w-md mx-6 lg:mx-12">
          <div className="relative w-full">
            <form onSubmit={handleSearch} className="relative flex items-center w-full">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search imported products..."
                className="w-full bg-[#7f1d1d]  py-1.5 px-4 text-sm focus:outline-none focus: text-[#ffffff] placeholder-white/50"
              />
              <button type="submit" className="absolute right-4 text-[10px] tracking-widest opacity-50 hover:opacity-100 cursor-pointer !bg-[#facc15] !text-[#7f1d1d] !border-none font-bold hover:!bg-[#eab308]">SEARCH</button>
            </form>
            {searchQuery.trim() !== '' && (
              <div className="absolute top-full left-0 w-full bg-[#7f1d1d]  shadow-xl mt-1 z-50 max-h-[300px] overflow-y-auto">
                {liveSearchResults.length > 0 ? (
                  liveSearchResults.map(product => (
                    <Link
                      key={product.id}
                      to={`/product/${product.id}`}
                      onClick={() => setSearchQuery('')}
                      className="flex items-center gap-3 p-3  hover:bg-[#991b1b] transition-colors"
                    >
                      <img src={product.image} alt={product.name} className="w-10 h-10 object-contain bg-[#991b1b] p-1 " />
                      <div className="flex flex-col">
                        <span className="text-xs font-bold truncate max-w-[200px]">{product.name}</span>
                        <span className="text-[10px] text-[#ffffff]/60 uppercase tracking-widest">{product.brand}</span>
                      </div>
                    </Link>
                  ))
                ) : (
                  <div className="p-4 text-xs text-[#ffffff]/60 text-center uppercase tracking-widest">No products found</div>
                )}
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-4 sm:gap-8 text-[10px] sm:text-xs tracking-widest font-medium uppercase">
          <Link to="/products?filter=offers" className="hidden sm:block hover:opacity-70 transition-opacity">Offers</Link>
          <Link to="/account" className="hidden sm:block hover:opacity-70 transition-opacity">Account</Link>
          <Link to="/cart" className="relative flex items-center hover:opacity-70 transition-opacity">
            <span>Cart</span>
            <span className="ml-2 bg-[#7f1d1d] text-[#ffffff] px-1.5 py-0.5 rounded-full text-[10px] font-bold">
              {totalItems}
            </span>
          </Link>
        </div>
      </header>

      {/* Mobile Search Bar */}
      <div className="md:hidden p-3  bg-[#7f1d1d] relative z-40">
        <form onSubmit={handleSearch} className="relative w-full flex items-center">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search products..."
            className="w-full bg-[#991b1b]  py-1.5 pl-4 pr-16 text-sm focus:outline-none focus: text-[#ffffff] placeholder-white/50"
          />
          <button type="submit" className="absolute right-4 text-[10px] tracking-widest opacity-50 hover:opacity-100 cursor-pointer !bg-[#facc15] !text-[#7f1d1d] !border-none font-bold hover:!bg-[#eab308]">SEARCH</button>
        </form>
        {searchQuery.trim() !== '' && (
          <div className="absolute top-full left-0 w-full bg-[#7f1d1d]  shadow-xl mt-1 z-50 max-h-[300px] overflow-y-auto">
            {liveSearchResults.length > 0 ? (
              liveSearchResults.map(product => (
                <Link
                  key={product.id}
                  to={`/product/${product.id}`}
                  onClick={() => setSearchQuery('')}
                  className="flex items-center gap-3 p-3  hover:bg-[#991b1b] transition-colors"
                >
                  <img src={product.image} alt={product.name} className="w-10 h-10 object-contain bg-[#991b1b] p-1 " />
                  <div className="flex flex-col">
                    <span className="text-xs font-bold truncate max-w-[200px]">{product.name}</span>
                    <span className="text-[10px] text-[#ffffff]/60 uppercase tracking-widest">{product.brand}</span>
                  </div>
                </Link>
              ))
            ) : (
              <div className="p-4 text-xs text-[#ffffff]/60 text-center uppercase tracking-widest">No products found</div>
            )}
          </div>
        )}
      </div>

      {/* Sidebar Overlay */}
      <AnimatePresence>
        {isMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMenuOpen(false)}
              className="fixed inset-0 bg-[#991b1b] z-50"
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', bounce: 0, duration: 0.4 }}
              className="fixed inset-y-0 left-0 w-80 bg-[#7f1d1d] z-50 shadow-2xl flex flex-col overflow-y-auto "
            >
              <div className="p-6 bg-[#991b1b] flex justify-between items-center ">
                <h1 className="text-xl tracking-[0.2em] font-bold font-serif uppercase">
                  SONI'S
                </h1>
                <button onClick={() => setIsMenuOpen(false)} className="text-[#ffffff] opacity-50 hover:opacity-100 transition-opacity">
                  <X size={24} strokeWidth={1} />
                </button>
              </div>

              <div className="py-6">
                <div className="px-8 pb-4 text-[10px] font-bold text-[#ffffff]/40 uppercase tracking-[0.3em]">Menu</div>
                {navLinks.map((link) => (
                  <Link
                    key={link.name}
                    to={link.path}
                    onClick={() => setIsMenuOpen(false)}
                    className="block px-8 py-3 text-sm tracking-[0.2em] font-bold hover:bg-[#7f1d1d]/5 transition-colors uppercase"
                  >
                    {link.name}
                  </Link>
                ))}

                <div className="px-8 pt-8 pb-4 text-[10px] font-bold text-[#ffffff]/40 uppercase tracking-[0.3em] mt-4 ">
                  Categories
                </div>
                {categories.map((cat) => (
                  <Link
                    key={cat.id}
                    to={`/products?category=${cat.id}`}
                    onClick={() => setIsMenuOpen(false)}
                    className="block px-8 py-2.5 text-xs tracking-widest font-bold hover:bg-[#7f1d1d]/5 transition-colors text-[#ffffff]/80 uppercase"
                  >
                    {cat.name}
                  </Link>
                ))}
              </div>
              
              <div className="mt-auto p-6 bg-[#991b1b] ">
                <div className="text-[10px] tracking-widest text-[#ffffff]/50 mb-4">NEED HELP?</div>
                <a href="https://wa.me/919999999999" target="_blank" rel="noreferrer" className="flex items-center justify-center w-full  text-[#ffffff] py-3 text-xs tracking-widest bg-[#facc15] text-[#7f1d1d] hover:bg-[#eab308] border-none font-bold transition-colors uppercase">
                  WhatsApp Support
                </a>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
