import React from 'react';
import { Link } from 'react-router-dom';
import { Product } from '../types';
import { useCart } from '../context/CartContext';
import { motion } from 'motion/react';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useCart();

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="group flex flex-col space-y-4"
    >
      <Link to={`/product/${product.id}`} className="block relative aspect-square bg-[#7f1d1d]  flex items-center justify-center overflow-hidden hover: transition-colors">
        {product.isNewArrival && (
          <span className="absolute top-2 left-2 text-[8px]  px-2 py-0.5 uppercase tracking-widest z-10 bg-[#991b1b]/50 backdrop-blur-sm">
            New
          </span>
        )}
        {product.discountPrice && (
          <span className="absolute top-2 right-2 text-[8px]  px-2 py-0.5 uppercase tracking-widest z-10 bg-[#991b1b]/50 backdrop-blur-sm">
            Sale
          </span>
        )}
        
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-full object-contain opacity-100 group-hover:scale-105 transition-all duration-700 "
        />
      </Link>

      <div className="flex flex-col flex-1 px-1 mt-2 mb-2">
        <Link to={`/product/${product.id}`} className="flex-1">
          <p className="font-bold text-[11px] leading-tight text-[#ffffff] line-clamp-2 mb-1">{product.name}</p>
          <p className="opacity-70 text-[9px] uppercase">
            {product.brand} {product.sizes?.[0] ? `• ${product.sizes[0]}` : ''}
          </p>
        </Link>
        <div className="mt-2 flex items-center justify-between">
          <div>
            {product.discountPrice ? (
              <div className="flex flex-col">
                <span className="text-[11px] font-bold">₹{product.discountPrice}</span>
                <span className="text-[9px] opacity-50 line-through">₹{product.price}</span>
              </div>
            ) : (
              <span className="text-[11px] font-bold">₹{product.price}</span>
            )}
          </div>
          <button
            onClick={(e) => {
              e.preventDefault();
              addToCart(product, 1, product.sizes?.[0], product.flavours?.[0]);
            }}
            className="bg-[#facc15] text-[#7f1d1d] px-3 py-1.5 text-[10px] font-bold hover:bg-[#eab308] transition-colors rounded-sm"
          >
            ADD
          </button>
        </div>
      </div>
    </motion.div>
  );
}
