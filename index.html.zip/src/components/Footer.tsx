import React from 'react';
import { MapPin, Phone, Mail, Instagram, Facebook } from 'lucide-react';
import { Link } from 'react-router-dom';

export function Footer() {
  return (
    <footer className="bg-[#7f1d1d]  flex-none flex flex-col md:flex-row items-center justify-between px-4 sm:px-8 py-6 gap-6 md:gap-0">
      <div className="flex flex-col gap-1 text-center md:text-left">
        <p className="text-[10px] tracking-widest font-bold uppercase">SONI'S FROZEN HUB, AJMER</p>
        <p className="text-[9px] opacity-50 uppercase tracking-wider">Papa House, Vaishali Nagar, Rajasthan</p>
      </div>
      <div className="flex flex-col md:flex-row items-center gap-6 md:gap-8">
        <div className="flex flex-col items-center md:items-end gap-2">
          <p className="text-[9px] opacity-50 tracking-widest uppercase">SECURE PAYMENTS</p>
          <div className="flex gap-3 items-center grayscale opacity-70">
            <span className="text-[10px]  px-1.5 py-0.5 uppercase tracking-widest">UPI</span>
            <span className="text-[10px]  px-1.5 py-0.5 uppercase tracking-widest">VISA</span>
            <span className="text-[10px]  px-1.5 py-0.5 uppercase tracking-widest">COD</span>
          </div>
        </div>
        <div className="hidden md:block h-10 w-[1px] bg-yellow-200"></div>
        <Link 
          to="/track-order"
          className="flex items-center gap-2 bg-[#991b1b] text-[#ffffff] bg-[#facc15] text-[#7f1d1d] border-none px-4 py-2 font-bold text-[10px] font-bold tracking-widest uppercase hover:bg-[#eab308] transition-colors"
        >
          TRACK ORDER
        </Link>
        <a 
          href="https://wa.me/919999999999" 
          target="_blank" 
          rel="noreferrer"
          className="flex items-center gap-2 bg-[#25D366]/10 text-[#25D366] /30 px-4 py-2 text-[10px] font-bold tracking-widest uppercase hover:bg-[#25D366]/20 transition-colors"
        >
          WHATSAPP SUPPORT
        </a>
      </div>
    </footer>
  );
}
