export interface Product {
  id: string;
  name: string;
  brand: string;
  description: string;
  price: number;
  discountPrice?: number;
  image: string;
  category: string;
  sizes?: string[];
  flavours?: string[];
  inStock: boolean;
  reviews: Review[];
  rating: number;
  isNewArrival?: boolean;
  isBestSeller?: boolean;
}

export interface Review {
  id: string;
  user: string;
  rating: number;
  comment: string;
  date: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedSize?: string;
  selectedFlavour?: string;
}

export interface Category {
  id: string;
  name: string;
  image: string;
}
