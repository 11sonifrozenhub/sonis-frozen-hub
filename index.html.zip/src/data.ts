import { Product, Category } from './types';

export const categories: Category[] = [
  { id: 'imported-drinks', name: 'Imported Drinks', image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80' },
  { id: 'imported-snacks', name: 'Imported Snacks', image: 'https://images.unsplash.com/photo-1599490659213-e2b9527bd087?w=500&q=80' },
  { id: 'frozen-products', name: 'Frozen Products', image: 'https://images.unsplash.com/photo-1582293041079-7814c2f12063?w=500&q=80' },
  { id: 'ice-cream-desserts', name: 'Ice Cream & Desserts', image: 'https://images.unsplash.com/photo-1559703248-dcaaec9fab78?w=500&q=80' },
  { id: 'grocery', name: 'Grocery', image: 'https://images.unsplash.com/photo-1583258292688-d0213dc5a3a8?w=500&q=80' },
  { id: 'special-collections', name: 'Special Collections', image: 'https://images.unsplash.com/photo-1607344645866-bea1b41c0342?w=500&q=80' },
];

export const products: Product[] = [
  {
    id: 'p1',
    name: 'Prime Hydration Drink - Imported',
    brand: 'Prime',
    description: 'Premium hydration drink imported directly. Zero added sugar, 10% coconut water, BCAA for muscle recovery, B Vitamins, Antioxidants, and Electrolytes.',
    price: 999,
    discountPrice: 799,
    image: 'https://images.unsplash.com/photo-1662057398322-262f279ee664?w=500&q=80',
    category: 'imported-drinks',
    flavours: ['Ice Pop', 'Blue Raspberry', 'Tropical Punch', 'Meta Moon'],
    inStock: true,
    reviews: [{ id: 'r1', user: 'Rahul S.', rating: 5, comment: 'Authentic product, fast delivery.', date: '2023-10-12' }],
    rating: 4.8,
    isBestSeller: true,
  },
  {
    id: 'p2',
    name: 'Monster Energy Ultra White - Imported',
    brand: 'Monster Energy',
    description: 'Zero sugar imported Monster Energy drink. Light, crisp, and refreshing with the full Monster energy blend.',
    price: 350,
    discountPrice: 299,
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'imported-drinks',
    inStock: true,
    reviews: [],
    rating: 4.5,
    isNewArrival: true,
  },
  {
    id: 'p3',
    name: 'Takis Fuego Rolled Tortilla Chips',
    brand: 'Takis',
    description: 'Hot chili pepper and lime flavored rolled tortilla chips. Imported from the USA.',
    price: 450,
    image: 'https://images.unsplash.com/photo-1599490659213-e2b9527bd087?w=500&q=80',
    category: 'imported-snacks',
    sizes: ['113g', '280g'],
    inStock: true,
    reviews: [],
    rating: 4.7,
    isBestSeller: true,
  },
  {
    id: 'p4',
    name: 'Hershey\'s Kisses Special Dark Mildly Sweet Chocolate',
    brand: 'Hershey\'s',
    description: 'Imported special dark mildly sweet chocolate candy sharing size bag.',
    price: 850,
    discountPrice: 750,
    image: 'https://images.unsplash.com/photo-1621317762635-c3971e411ba7?w=500&q=80',
    category: 'imported-snacks',
    inStock: true,
    reviews: [],
    rating: 4.9,
  },
  {
    id: 'p5',
    name: 'McCain Premium French Fries',
    brand: 'McCain',
    description: 'Crispy and delicious frozen french fries, perfect for a quick snack.',
    price: 220,
    image: 'https://images.unsplash.com/photo-1576107255743-1570773663a8?w=500&q=80',
    category: 'frozen-products',
    sizes: ['400g', '1kg'],
    inStock: true,
    reviews: [],
    rating: 4.3,
  },
  {
    id: 'p6',
    name: 'Haagen-Dazs Belgian Chocolate Ice Cream',
    brand: 'Haagen-Dazs',
    description: 'Imported premium Belgian chocolate ice cream crafted with real Belgian chocolate.',
    price: 850,
    image: 'https://images.unsplash.com/photo-1559703248-dcaaec9fab78?w=500&q=80',
    category: 'ice-cream-desserts',
    inStock: true,
    reviews: [],
    rating: 5.0,
    isBestSeller: true,
  },
  {
    id: 'p7',
    name: 'Barilla Spaghetti Pasta',
    brand: 'Barilla',
    description: 'Classic Italian spaghetti pasta. Perfect for all kinds of pasta dishes.',
    price: 299,
    image: 'https://images.unsplash.com/photo-1583258292688-d0213dc5a3a8?w=500&q=80',
    category: 'grocery',
    sizes: ['500g'],
    inStock: true,
    reviews: [],
    rating: 4.6,
  },
  {
    id: 'p8',
    name: 'Luxury Gift Hamper - Imported Snacks & Drinks',
    brand: "SONI'S Collection",
    description: 'A curated gift box containing premium imported chocolates, snacks, and a prime energy drink.',
    price: 2999,
    discountPrice: 2499,
    image: 'https://images.unsplash.com/photo-1607344645866-bea1b41c0342?w=500&q=80',
    category: 'special-collections',
    inStock: true,
    reviews: [],
    rating: 4.9,
    isNewArrival: true,
  }
,
  {
    id: 'gen-product-1',
    name: 'Premium Imported Product 1',
    brand: 'Lindt',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 153,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'imported-drinks',
    
    
    
  },
  {
    id: 'gen-product-2',
    name: 'Premium Imported Product 2',
    brand: 'Ferrero',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 520,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'frozen-products',
    isNewArrival: true,
    
    
  },
  {
    id: 'gen-product-3',
    name: 'Premium Imported Product 3',
    brand: 'Pringles',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 289,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'ice-cream-desserts',
    
    flavours: ['Original', 'Spicy', 'Sweet'],
    
  },
  {
    id: 'gen-product-4',
    name: 'Premium Imported Product 4',
    brand: 'Lotte',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 289,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'grocery',
    
    
    sizes: ['Small', 'Medium', 'Large'],
  },
  {
    id: 'gen-product-5',
    name: 'Premium Imported Product 5',
    brand: 'Haribo',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 433,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'special-collections',
    isNewArrival: true,
    
    
  },
  {
    id: 'gen-product-6',
    name: 'Premium Imported Product 6',
    brand: 'Milka',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 162,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'imported-snacks',
    isNewArrival: true,
    flavours: ['Original', 'Spicy', 'Sweet'],
    
  },
  {
    id: 'gen-product-7',
    name: 'Premium Imported Product 7',
    brand: 'Toblerone',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 427,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'imported-drinks',
    isNewArrival: true,
    
    
  },
  {
    id: 'gen-product-8',
    name: 'Premium Imported Product 8',
    brand: 'Kinder',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 222,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'frozen-products',
    
    
    sizes: ['Small', 'Medium', 'Large'],
  },
  {
    id: 'gen-product-9',
    name: 'Premium Imported Product 9',
    brand: 'Ritter Sport',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 596,
    discountPrice: 567,
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'ice-cream-desserts',
    isNewArrival: true,
    flavours: ['Original', 'Spicy', 'Sweet'],
    
  },
  {
    id: 'gen-product-10',
    name: 'Premium Imported Product 10',
    brand: 'Nestlé',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 467,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'grocery',
    isNewArrival: true,
    
    
  },
  {
    id: 'gen-product-11',
    name: 'Premium Imported Product 11',
    brand: 'Lindt',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 281,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'special-collections',
    
    
    
  },
  {
    id: 'gen-product-12',
    name: 'Premium Imported Product 12',
    brand: 'Ferrero',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 485,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'imported-snacks',
    isNewArrival: true,
    flavours: ['Original', 'Spicy', 'Sweet'],
    sizes: ['Small', 'Medium', 'Large'],
  },
  {
    id: 'gen-product-13',
    name: 'Premium Imported Product 13',
    brand: 'Pringles',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 330,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'imported-drinks',
    
    
    
  },
  {
    id: 'gen-product-14',
    name: 'Premium Imported Product 14',
    brand: 'Lotte',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 376,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'frozen-products',
    isNewArrival: true,
    
    
  },
  {
    id: 'gen-product-15',
    name: 'Premium Imported Product 15',
    brand: 'Haribo',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 323,
    discountPrice: 275,
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'ice-cream-desserts',
    
    flavours: ['Original', 'Spicy', 'Sweet'],
    
  },
  {
    id: 'gen-product-16',
    name: 'Premium Imported Product 16',
    brand: 'Milka',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 445,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'grocery',
    isNewArrival: true,
    
    sizes: ['Small', 'Medium', 'Large'],
  },
  {
    id: 'gen-product-17',
    name: 'Premium Imported Product 17',
    brand: 'Toblerone',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 495,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'special-collections',
    isNewArrival: true,
    
    
  },
  {
    id: 'gen-product-18',
    name: 'Premium Imported Product 18',
    brand: 'Kinder',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 141,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'imported-snacks',
    
    flavours: ['Original', 'Spicy', 'Sweet'],
    
  },
  {
    id: 'gen-product-19',
    name: 'Premium Imported Product 19',
    brand: 'Ritter Sport',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 537,
    discountPrice: 504,
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'imported-drinks',
    isNewArrival: true,
    
    
  },
  {
    id: 'gen-product-20',
    name: 'Premium Imported Product 20',
    brand: 'Nestlé',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 572,
    discountPrice: 518,
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'frozen-products',
    
    
    sizes: ['Small', 'Medium', 'Large'],
  },
  {
    id: 'gen-product-21',
    name: 'Premium Imported Product 21',
    brand: 'Lindt',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 509,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'ice-cream-desserts',
    isNewArrival: true,
    flavours: ['Original', 'Spicy', 'Sweet'],
    
  },
  {
    id: 'gen-product-22',
    name: 'Premium Imported Product 22',
    brand: 'Ferrero',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 387,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'grocery',
    isNewArrival: true,
    
    
  },
  {
    id: 'gen-product-23',
    name: 'Premium Imported Product 23',
    brand: 'Pringles',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 431,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'special-collections',
    isNewArrival: true,
    
    
  },
  {
    id: 'gen-product-24',
    name: 'Premium Imported Product 24',
    brand: 'Lotte',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 454,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'imported-snacks',
    isNewArrival: true,
    flavours: ['Original', 'Spicy', 'Sweet'],
    sizes: ['Small', 'Medium', 'Large'],
  },
  {
    id: 'gen-product-25',
    name: 'Premium Imported Product 25',
    brand: 'Haribo',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 197,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'imported-drinks',
    isNewArrival: true,
    
    
  },
  {
    id: 'gen-product-26',
    name: 'Premium Imported Product 26',
    brand: 'Milka',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 571,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'frozen-products',
    isNewArrival: true,
    
    
  },
  {
    id: 'gen-product-27',
    name: 'Premium Imported Product 27',
    brand: 'Toblerone',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 493,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'ice-cream-desserts',
    isNewArrival: true,
    flavours: ['Original', 'Spicy', 'Sweet'],
    
  },
  {
    id: 'gen-product-28',
    name: 'Premium Imported Product 28',
    brand: 'Kinder',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 106,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'grocery',
    isNewArrival: true,
    
    sizes: ['Small', 'Medium', 'Large'],
  },
  {
    id: 'gen-product-29',
    name: 'Premium Imported Product 29',
    brand: 'Ritter Sport',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 192,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'special-collections',
    
    
    
  },
  {
    id: 'gen-product-30',
    name: 'Premium Imported Product 30',
    brand: 'Nestlé',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 381,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'imported-snacks',
    isNewArrival: true,
    flavours: ['Original', 'Spicy', 'Sweet'],
    
  },
  {
    id: 'gen-product-31',
    name: 'Premium Imported Product 31',
    brand: 'Lindt',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 582,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'imported-drinks',
    
    
    
  },
  {
    id: 'gen-product-32',
    name: 'Premium Imported Product 32',
    brand: 'Ferrero',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 237,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'frozen-products',
    
    
    sizes: ['Small', 'Medium', 'Large'],
  },
  {
    id: 'gen-product-33',
    name: 'Premium Imported Product 33',
    brand: 'Pringles',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 135,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'ice-cream-desserts',
    isNewArrival: true,
    flavours: ['Original', 'Spicy', 'Sweet'],
    
  },
  {
    id: 'gen-product-34',
    name: 'Premium Imported Product 34',
    brand: 'Lotte',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 336,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'grocery',
    
    
    
  },
  {
    id: 'gen-product-35',
    name: 'Premium Imported Product 35',
    brand: 'Haribo',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 409,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'special-collections',
    isNewArrival: true,
    
    
  },
  {
    id: 'gen-product-36',
    name: 'Premium Imported Product 36',
    brand: 'Milka',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 128,
    discountPrice: 82,
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'imported-snacks',
    
    flavours: ['Original', 'Spicy', 'Sweet'],
    sizes: ['Small', 'Medium', 'Large'],
  },
  {
    id: 'gen-product-37',
    name: 'Premium Imported Product 37',
    brand: 'Toblerone',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 339,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'imported-drinks',
    
    
    
  },
  {
    id: 'gen-product-38',
    name: 'Premium Imported Product 38',
    brand: 'Kinder',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 544,
    discountPrice: 486,
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'frozen-products',
    
    
    
  },
  {
    id: 'gen-product-39',
    name: 'Premium Imported Product 39',
    brand: 'Ritter Sport',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 258,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'ice-cream-desserts',
    isNewArrival: true,
    flavours: ['Original', 'Spicy', 'Sweet'],
    
  },
  {
    id: 'gen-product-40',
    name: 'Premium Imported Product 40',
    brand: 'Nestlé',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 542,
    discountPrice: 499,
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'grocery',
    isNewArrival: true,
    
    sizes: ['Small', 'Medium', 'Large'],
  },
  {
    id: 'gen-product-41',
    name: 'Premium Imported Product 41',
    brand: 'Lindt',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 259,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'special-collections',
    isNewArrival: true,
    
    
  },
  {
    id: 'gen-product-42',
    name: 'Premium Imported Product 42',
    brand: 'Ferrero',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 431,
    discountPrice: 409,
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'imported-snacks',
    isNewArrival: true,
    flavours: ['Original', 'Spicy', 'Sweet'],
    
  },
  {
    id: 'gen-product-43',
    name: 'Premium Imported Product 43',
    brand: 'Pringles',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 214,
    discountPrice: 165,
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'imported-drinks',
    
    
    
  },
  {
    id: 'gen-product-44',
    name: 'Premium Imported Product 44',
    brand: 'Lotte',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 110,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'frozen-products',
    isNewArrival: true,
    
    sizes: ['Small', 'Medium', 'Large'],
  },
  {
    id: 'gen-product-45',
    name: 'Premium Imported Product 45',
    brand: 'Haribo',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 421,
    discountPrice: 376,
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'ice-cream-desserts',
    
    flavours: ['Original', 'Spicy', 'Sweet'],
    
  },
  {
    id: 'gen-product-46',
    name: 'Premium Imported Product 46',
    brand: 'Milka',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 403,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'grocery',
    isNewArrival: true,
    
    
  },
  {
    id: 'gen-product-47',
    name: 'Premium Imported Product 47',
    brand: 'Toblerone',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 255,
    discountPrice: 206,
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'special-collections',
    
    
    
  },
  {
    id: 'gen-product-48',
    name: 'Premium Imported Product 48',
    brand: 'Kinder',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 478,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'imported-snacks',
    isNewArrival: true,
    flavours: ['Original', 'Spicy', 'Sweet'],
    sizes: ['Small', 'Medium', 'Large'],
  },
  {
    id: 'gen-product-49',
    name: 'Premium Imported Product 49',
    brand: 'Ritter Sport',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 179,
    discountPrice: 155,
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'imported-drinks',
    
    
    
  },
  {
    id: 'gen-product-50',
    name: 'Premium Imported Product 50',
    brand: 'Nestlé',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: 263,
    
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: 'frozen-products',
    
    
    
  }
];

const brands = ["Nestlé", "Lindt", "Ferrero", "Pringles", "Lotte", "Haribo", "Milka", "Toblerone", "Kinder", "Ritter Sport"];
const bulkCategories = ["imported-snacks", "imported-drinks", "frozen-products", "ice-cream-desserts", "grocery", "special-collections"];

for (let i = 1; i <= 10000; i++) {
  const isNewArrival = Math.random() > 0.5;
  const hasDiscount = Math.random() > 0.7;
  const price = Math.floor(Math.random() * 500) + 100;
  const discountPrice = hasDiscount ? price - Math.floor(Math.random() * 50) - 10 : undefined;
  
  products.push({
    id: `bulk-product-${i}`,
    name: `Premium Bulk Product ${i}`,
    brand: brands[i % brands.length],
    description: 'This is a bulk generated premium product for testing extreme list performance.',
    price,
    discountPrice,
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: bulkCategories[i % bulkCategories.length],
    isNewArrival,
    flavours: i % 3 === 0 ? ['Original', 'Spicy', 'Sweet'] : undefined,
    sizes: i % 4 === 0 ? ['Small', 'Medium', 'Large'] : undefined
  });
}
