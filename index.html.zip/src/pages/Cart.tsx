import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { Minus, Plus, X, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

export function Cart() {
  const { items, removeFromCart, updateQuantity, totalPrice } = useCart();

  if (items.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center min-h-[60vh] flex flex-col items-center justify-center flex-1">
        <h2 className="text-4xl font-serif font-bold  mb-6">Your Cart is Empty</h2>
        <p className="text-[#ffffff]/50 mb-10 text-xs tracking-widest uppercase">Looks like you haven't added anything to your cart yet.</p>
        <Link to="/products" className=" bg-[#7f1d1d] text-[#ffffff] px-8 py-4 text-[10px] font-bold uppercase tracking-[0.3em] hover:bg-transparent hover:text-[#ffffff] transition-colors inline-block">
          Continue Shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 flex-1">
      <h1 className="text-3xl font-serif font-bold  mb-8">Shopping Cart</h1>
      
      <div className="grid lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2">
          <div className="hidden sm:grid grid-cols-6 gap-4 pb-4  text-[10px] font-bold uppercase tracking-[0.2em] text-[#ffffff]/50">
            <div className="col-span-3">Product</div>
            <div className="text-center">Quantity</div>
            <div className="text-right">Total</div>
            <div></div>
          </div>
          
          <div className="divide-y divide-white/10">
            {items.map((item, index) => {
              const price = item.product.discountPrice || item.product.price;
              
              return (
                <motion.div 
                  key={`${item.product.id}-${index}`}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="py-6 flex flex-col sm:grid sm:grid-cols-6 gap-4 items-center"
                >
                  <div className="col-span-3 flex items-center gap-6 w-full">
                    <Link to={`/product/${item.product.id}`} className="shrink-0">
                      <div className="w-24 h-24 bg-[#7f1d1d] p-2  flex items-center justify-center overflow-hidden">
                        <img src={item.product.image} alt={item.product.name} className="w-full h-full object-contain opacity-100" />
                      </div>
                    </Link>
                    <div>
                      <div className="text-[10px] text-[#ffffff]/50 uppercase tracking-widest mb-1">{item.product.brand}</div>
                      <Link to={`/product/${item.product.id}`} className="text-sm font-medium hover:text-[#ffffff]/80 transition-colors line-clamp-2 leading-relaxed">
                        {item.product.name}
                      </Link>
                      <div className="text-[10px] text-[#ffffff]/50 mt-2 tracking-widest uppercase">
                        {item.selectedFlavour && <span>{item.selectedFlavour}</span>}
                        {item.selectedFlavour && item.selectedSize && <span> / </span>}
                        {item.selectedSize && <span>{item.selectedSize}</span>}
                      </div>
                      <div className="sm:hidden font-bold mt-2">₹{price}</div>
                    </div>
                  </div>
                  
                  <div className="w-full sm:w-auto flex justify-between sm:justify-center items-center mt-4 sm:mt-0">
                    <span className="sm:hidden text-[10px] font-bold uppercase tracking-widest text-[#ffffff]/50">Quantity</span>
                    <div className="flex items-center ">
                      <button 
                        onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                        className="p-2 text-[#ffffff]/50 hover:text-[#ffffff] transition-colors"
                      >
                        <Minus size={14} />
                      </button>
                      <span className="w-8 text-center text-xs font-medium">{item.quantity}</span>
                      <button 
                        onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                        className="p-2 text-[#ffffff]/50 hover:text-[#ffffff] transition-colors"
                      >
                        <Plus size={14} />
                      </button>
                    </div>
                  </div>
                  
                  <div className="hidden sm:block text-right font-medium text-sm">
                    ₹{price * item.quantity}
                  </div>
                  
                  <div className="w-full sm:w-auto text-right mt-2 sm:mt-0">
                    <button 
                      onClick={() => removeFromCart(item.product.id)}
                      className="text-[#ffffff]/40 hover:text-[#ffffff] text-[10px] flex items-center justify-end w-full gap-1 uppercase tracking-[0.2em] font-medium transition-colors"
                    >
                      <X size={14} className="sm:hidden" />
                      <span className="sm:hidden">Remove</span>
                      <X size={18} className="hidden sm:block" />
                    </button>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
        
        <div className="lg:col-span-1">
          <div className="bg-[#7f1d1d] p-6 sm:p-8  sticky top-28">
            <h2 className="text-lg font-serif font-bold  mb-6">Order Summary</h2>
            
            <div className="space-y-4 text-xs mb-6  pb-6 tracking-wide">
              <div className="flex justify-between">
                <span className="text-[#ffffff]/70">Subtotal</span>
                <span className="font-medium">₹{totalPrice}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#ffffff]/70">Shipping</span>
                <span className="font-medium text-[#ffffff]/50">Calculated at checkout</span>
              </div>
            </div>
            
            <div className="flex justify-between items-center mb-8">
              <span className="text-[10px] font-bold uppercase tracking-[0.3em]">Total</span>
              <span className="text-2xl font-bold">₹{totalPrice}</span>
            </div>
            
            <Link 
              to="/checkout"
              className="w-full  bg-[#7f1d1d] text-[#ffffff] flex items-center justify-center gap-3 py-4 text-[10px] font-bold uppercase tracking-[0.3em] hover:bg-transparent hover:text-[#ffffff] transition-colors"
            >
              Checkout <ArrowRight size={16} />
            </Link>
            
            <p className="text-[10px] text-center text-[#ffffff]/50 mt-4 tracking-widest uppercase">
              Taxes and shipping calculated at checkout
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
