import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ArrowRight, Star, ShieldCheck, Truck, Clock } from 'lucide-react';
import { categories, products } from '../data';
import { ProductCard } from '../components/ProductCard';

export function Home() {
  const newArrivals = products.filter(p => p.isNewArrival).slice(0, 6);
  const bestSellers = products.filter(p => p.isBestSeller).slice(0, 6);
  const offers = products.filter(p => p.discountPrice).slice(0, 6);

  return (
    <div className="flex flex-col flex-1 overflow-hidden bg-[#991b1b] text-[#ffffff]">
      {/* Hero Section */}
      <section className="min-h-[500px] md:h-[600px] bg-[#7f1d1d]  flex flex-col md:flex-row flex-none">
        <div className="md:w-1/2 p-8 md:p-12 flex flex-col justify-center gap-4 relative overflow-hidden">
          <div className="absolute inset-0 opacity-10 pointer-events-none">
            <img 
              src="https://images.unsplash.com/photo-1604719312566-8912e9227c6a?w=1600&q=80" 
              alt="Premium Store Texture" 
              className="w-full h-full object-cover"
            />
          </div>
          <div className="relative z-10">
            <motion.span 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-xs tracking-[0.4em] text-[#ffffff]/50 block mb-2"
            >
              EXCLUSIVE IMPORTS
            </motion.span>
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight  font-serif mb-4"
            >
              Elevating Your <br/>Culinary Lifestyle.
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-sm text-[#ffffff]/60 max-w-sm leading-relaxed mb-6"
            >
              Ajmer's premier destination for luxury frozen delicacies and international snack collections.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
            >
              <Link 
                to="/products" 
                className="inline-block mt-4  px-8 py-3 text-xs tracking-[0.3em] bg-[#facc15] text-[#7f1d1d] hover:bg-[#eab308] border-none font-bold transition-colors w-max uppercase font-medium"
              >
                Shop Collection
              </Link>
            </motion.div>
          </div>
        </div>
        <div className="md:w-1/2 bg-[#b91c1c] flex items-center justify-center p-8 md:p-12">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="w-full max-w-md"
          >
            <div className="grid grid-cols-2 gap-4">
              {products.slice(0, 4).map(p => (
                <Link to={`/product/${p.id}`} key={p.id} className="bg-[#991b1b] aspect-square flex items-center justify-center p-4 relative group overflow-hidden shadow-xl rounded-md">
                  <img 
                    src={p.image} 
                    alt={p.name}
                    className="w-full h-full object-contain opacity-100 group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 flex items-end justify-center pb-2 opacity-0 group-hover:opacity-100 transition-opacity bg-gradient-to-t from-black/50 to-transparent">
                    <span className="text-[9px] uppercase font-bold text-[#ffffff] truncate px-2 text-center w-full">{p.name}</span>
                  </div>
                </Link>
              ))}
            </div>
            <div className="text-[10px] tracking-[0.2em] uppercase text-[#ffffff]/70 text-center mt-8 font-bold">
              Featured Imports
            </div>
          </motion.div>
        </div>
      </section>

      {/* Categories */}
      <section className="flex-none p-6 md:p-12 bg-[#991b1b] ">
        <div className="flex justify-between items-end mb-8">
          <h3 className="text-sm tracking-[0.3em] font-semibold text-[#ffffff]/90">FEATURED CATEGORIES</h3>
          <Link to="/products" className="text-[10px]  opacity-50 hover:opacity-100 transition-opacity uppercase tracking-widest pb-0.5">
            VIEW ALL
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2">
          {categories.map((category) => (
            <Link 
              key={category.id}
              to={`/products?category=${category.id}`}
              className="bg-[#7f1d1d] p-4 h-28 flex flex-col justify-between group cursor-pointer transition-colors rounded-sm shadow-sm"
            >
              <div className="text-[10px] font-bold tracking-widest uppercase text-[#ffffff]/80 group-hover:text-[#ffffff] leading-tight">
                {category.name}
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Trending / Best Sellers */}
      <section className="flex-1 p-6 md:p-12 flex flex-col gap-8 bg-[#991b1b]">
        <div className="flex justify-between items-center  pb-6">
          <h3 className="text-sm tracking-[0.3em] font-semibold text-[#ffffff]/90 uppercase">TRENDING NOW</h3>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2">
          {bestSellers.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* Banner */}
      <section className="py-24 bg-[#7f1d1d] text-center px-4  relative overflow-hidden">
        <div className="absolute inset-0 opacity-5 pointer-events-none">
          <img 
            src="https://images.unsplash.com/photo-1542838132-92c53300491e?w=800&q=80" 
            alt="Background" 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="max-w-2xl mx-auto relative z-10">
          <h2 className="text-3xl md:text-4xl font-serif font-bold  leading-relaxed mb-6">"Bringing the world's finest flavors directly to your home."</h2>
          <p className="text-[#ffffff]/50 mb-10 text-xs tracking-widest uppercase">Discover rare snacks and limited edition beverages.</p>
          <Link to="/products?category=special-collections" className="inline-block  px-8 py-3 text-xs tracking-[0.3em] bg-[#facc15] text-[#7f1d1d] hover:bg-[#eab308] border-none font-bold transition-colors uppercase">
            Explore Collection
          </Link>
        </div>
      </section>

      {/* New Arrivals */}
      <section className="flex-1 p-6 md:p-12 flex flex-col gap-8 bg-[#991b1b] ">
        <div className="flex justify-between items-center  pb-6">
          <h3 className="text-sm tracking-[0.3em] font-semibold text-[#ffffff]/90 uppercase">NEW ARRIVALS</h3>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2">
          {newArrivals.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>
    </div>
  );
}
