import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Search, Package, Truck, CheckCircle } from 'lucide-react';
import { useLocation } from 'react-router-dom';

export function TrackOrder() {
  const location = useLocation();
  const state = location.state as { orderId?: string };
  const initialOrderId = state?.orderId || '';

  const [orderId, setOrderId] = useState(initialOrderId);
  const [tracking, setTracking] = useState(!!initialOrderId);

  const handleTrack = (e: React.FormEvent) => {
    e.preventDefault();
    if (orderId) setTracking(true);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-20 flex-1 w-full">
      <h1 className="text-4xl font-serif font-bold uppercase mb-8 text-center text-yellow-500">Track Your Order</h1>
      
      <form onSubmit={handleTrack} className="flex gap-4 mb-16 justify-center">
        <input 
          type="text" 
          value={orderId}
          onChange={(e) => setOrderId(e.target.value)}
          placeholder="Enter Order ID (e.g. ORD-123456)" 
          className="border-4  p-4 w-full max-w-md font-bold focus:outline-none"
          required
        />
        <button type="submit" className="bg-[#991b1b] text-[#ffffff] px-8 py-4 font-bold uppercase hover:bg-[#eab308] transition-colors !bg-[#facc15] !text-[#7f1d1d] !border-none font-bold hover:!bg-[#eab308]">
          Track
        </button>
      </form>

      {tracking && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="border-4  p-8 bg-[#7f1d1d]"
        >
          <h2 className="text-2xl font-bold mb-8 uppercase text-center">Order Status: <span className="text-yellow-500">Processing</span></h2>
          
          <div className="flex flex-col sm:flex-row justify-between items-center gap-8 relative">
            <div className="absolute left-1/2 sm:left-0 sm:top-1/2 w-1 sm:w-full h-full sm:h-1 bg-yellow-100 -translate-x-1/2 sm:translate-x-0 sm:-translate-y-1/2 z-0"></div>
            
            <div className="relative z-10 flex flex-col items-center gap-4 bg-[#7f1d1d] p-4">
              <div className="w-16 h-16 rounded-full bg-[#991b1b] text-[#ffffff] flex items-center justify-center">
                <CheckCircle size={32} />
              </div>
              <span className="font-bold uppercase text-center">Order<br/>Placed</span>
            </div>
            
            <div className="relative z-10 flex flex-col items-center gap-4 bg-[#7f1d1d] p-4">
              <div className="w-16 h-16 rounded-full bg-[#991b1b] text-[#ffffff] flex items-center justify-center">
                <Package size={32} />
              </div>
              <span className="font-bold uppercase text-center">Order<br/>Packed</span>
            </div>
            
            <div className="relative z-10 flex flex-col items-center gap-4 bg-[#7f1d1d] p-4">
              <div className="w-16 h-16 rounded-full bg-gray-200 text-gray-400 flex items-center justify-center">
                <Truck size={32} />
              </div>
              <span className="font-bold uppercase text-center text-gray-400">Out for<br/>Delivery</span>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}
