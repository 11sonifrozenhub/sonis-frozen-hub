import React, { useState } from 'react';
import { useCart } from '../context/CartContext';
import { useNavigate, Link } from 'react-router-dom';
import { CheckCircle, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';

export function Checkout() {
  const { items, totalPrice, clearCart } = useCart();
  const navigate = useNavigate();
  const [paymentMethod, setPaymentMethod] = useState('upi');
  const [orderId, setOrderId] = useState('');

  const shipping = totalPrice > 500 ? 0 : 50;
  const finalTotal = totalPrice + shipping;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate payment processing
    setTimeout(() => {
      const newOrderId = 'ORD-' + Math.floor(Math.random() * 1000000);
      clearCart();
      navigate('/track-order', { state: { orderId: newOrderId } });
    }, 1500);
  };

  if (items.length === 0) {
    navigate('/cart');
    return null;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 flex-1">
      <h1 className="text-3xl font-serif font-bold  mb-12 text-center">Secure Checkout</h1>
      
      <div className="grid lg:grid-cols-2 gap-12 lg:gap-24">
        <div>
          <form onSubmit={handleSubmit} id="checkout-form">
            <div className="mb-10">
              <h2 className="text-[10px] font-bold uppercase tracking-[0.3em]  pb-4 mb-6 text-[#ffffff]/90">Contact Information</h2>
              <div className="space-y-4">
                <input required type="email" placeholder="Email Address" className="w-full bg-[#7f1d1d]  p-4 text-xs focus:ring-1 focus:ring-white focus: text-[#ffffff] placeholder-white/30 transition-colors" />
                <input required type="tel" placeholder="Phone Number" className="w-full bg-[#7f1d1d]  p-4 text-xs focus:ring-1 focus:ring-white focus: text-[#ffffff] placeholder-white/30 transition-colors" />
              </div>
            </div>

            <div className="mb-10">
              <h2 className="text-[10px] font-bold uppercase tracking-[0.3em]  pb-4 mb-6 text-[#ffffff]/90">Shipping Address</h2>
              <div className="grid grid-cols-2 gap-4">
                <input required type="text" placeholder="First Name" className="w-full bg-[#7f1d1d]  p-4 text-xs focus:ring-1 focus:ring-white focus: text-[#ffffff] placeholder-white/30 transition-colors" />
                <input required type="text" placeholder="Last Name" className="w-full bg-[#7f1d1d]  p-4 text-xs focus:ring-1 focus:ring-white focus: text-[#ffffff] placeholder-white/30 transition-colors" />
                <input required type="text" placeholder="Address" className="col-span-2 w-full bg-[#7f1d1d]  p-4 text-xs focus:ring-1 focus:ring-white focus: text-[#ffffff] placeholder-white/30 transition-colors" />
                <input type="text" placeholder="Apartment, suite, etc. (optional)" className="col-span-2 w-full bg-[#7f1d1d]  p-4 text-xs focus:ring-1 focus:ring-white focus: text-[#ffffff] placeholder-white/30 transition-colors" />
                <input required type="text" placeholder="City (Ajmer)" defaultValue="Ajmer" readOnly className="w-full bg-[#991b1b]  p-4 text-xs text-[#ffffff]/30 cursor-not-allowed" />
                <input required type="text" placeholder="PIN Code" className="w-full bg-[#7f1d1d]  p-4 text-xs focus:ring-1 focus:ring-white focus: text-[#ffffff] placeholder-white/30 transition-colors" />
              </div>
            </div>

            <div className="mb-10">
              <h2 className="text-[10px] font-bold uppercase tracking-[0.3em]  pb-4 mb-6 text-[#ffffff]/90">Payment Method</h2>
              <div className="space-y-3">
                <label className={`flex items-center gap-4 p-5 border cursor-pointer transition-colors ${paymentMethod === 'upi' ? ' bg-[#7f1d1d]/5' : ' hover:'}`}>
                  <input type="radio" name="payment" value="upi" checked={paymentMethod === 'upi'} onChange={() => setPaymentMethod('upi')} className="accent-white" />
                  <span className="font-medium text-xs tracking-wider">UPI (Google Pay, PhonePe, Paytm)</span>
                </label>
                <label className={`flex items-center gap-4 p-5 border cursor-pointer transition-colors ${paymentMethod === 'card' ? ' bg-[#7f1d1d]/5' : ' hover:'}`}>
                  <input type="radio" name="payment" value="card" checked={paymentMethod === 'card'} onChange={() => setPaymentMethod('card')} className="accent-white" />
                  <span className="font-medium text-xs tracking-wider">Credit / Debit Card</span>
                </label>
                <label className={`flex items-center gap-4 p-5 border cursor-pointer transition-colors ${paymentMethod === 'cod' ? ' bg-[#7f1d1d]/5' : ' hover:'}`}>
                  <input type="radio" name="payment" value="cod" checked={paymentMethod === 'cod'} onChange={() => setPaymentMethod('cod')} className="accent-white" />
                  <span className="font-medium text-xs tracking-wider">Cash on Delivery (COD)</span>
                </label>
              </div>
              
              {paymentMethod === 'upi' && (
                <div className="mt-4 p-6  bg-[#7f1d1d] text-xs text-center text-[#ffffff]/70 tracking-wide">
                  <p className="mb-4">Scan QR or enter UPI ID on the next step</p>
                  <div className="flex justify-center gap-3">
                    <span className=" px-3 py-1 text-[10px] uppercase tracking-widest">GPay</span>
                    <span className=" px-3 py-1 text-[10px] uppercase tracking-widest">PhonePe</span>
                    <span className=" px-3 py-1 text-[10px] uppercase tracking-widest">Paytm</span>
                  </div>
                </div>
              )}
            </div>

            <button type="submit" form="checkout-form" className="w-full bg-[#facc15] text-[#7f1d1d] hover:bg-[#eab308] border-none font-bold py-4 text-[10px] uppercase tracking-[0.3em] transition-colors flex justify-center items-center gap-3">
              <ShieldCheck size={16} /> Place Order
            </button>
          </form>
        </div>
        
        <div className="bg-[#7f1d1d] p-6 sm:p-8  h-fit sticky top-28">
          <h2 className="text-lg font-serif font-bold  mb-8">Order Summary</h2>
          
          <div className="divide-y divide-white/10 mb-8">
            {items.map((item, index) => (
              <div key={index} className="py-4 flex gap-6 items-center">
                <div className="w-16 h-16 bg-[#991b1b]  relative shrink-0 p-2 flex items-center justify-center">
                  <span className="absolute -top-2 -right-2 bg-[#7f1d1d] text-[#ffffff] text-[10px] w-5 h-5 flex items-center justify-center font-bold">
                    {item.quantity}
                  </span>
                  <img src={item.product.image} alt={item.product.name} className="w-full h-full object-contain opacity-100" />
                </div>
                <div className="flex-1">
                  <h4 className="text-xs font-medium line-clamp-2 tracking-wide leading-relaxed">{item.product.name}</h4>
                  <div className="text-[10px] text-[#ffffff]/50 mt-1 uppercase tracking-widest">
                    {item.selectedFlavour && <span>{item.selectedFlavour}</span>}
                    {item.selectedFlavour && item.selectedSize && <span> / </span>}
                    {item.selectedSize && <span>{item.selectedSize}</span>}
                  </div>
                </div>
                <div className="font-medium text-xs">
                  ₹{(item.product.discountPrice || item.product.price) * item.quantity}
                </div>
              </div>
            ))}
          </div>

          <div className="space-y-4 text-xs mb-8  pb-8 tracking-wide">
            <div className="flex justify-between">
              <span className="text-[#ffffff]/70">Subtotal</span>
              <span className="font-medium">₹{totalPrice}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#ffffff]/70">Shipping</span>
              <span className="font-medium">{shipping === 0 ? 'Free' : `₹${shipping}`}</span>
            </div>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-[10px] font-bold uppercase tracking-[0.3em]">Total</span>
            <span className="text-2xl font-bold">₹{finalTotal}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
