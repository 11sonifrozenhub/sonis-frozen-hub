import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { products, categories } from '../data';
import { ProductCard } from '../components/ProductCard';
import { Filter } from 'lucide-react';

export function Products() {
  const [searchParams, setSearchParams] = useSearchParams();
  const categoryFilter = searchParams.get('category');
  const searchFilter = searchParams.get('search');
  const [sortBy, setSortBy] = useState('featured');
  const [isMobileFiltersOpen, setIsMobileFiltersOpen] = useState(false);
  const [visibleCount, setVisibleCount] = useState(24);

  let filteredProducts = [...products];

  if (categoryFilter) {
    filteredProducts = filteredProducts.filter(p => p.category === categoryFilter);
  }

  if (searchFilter) {
    const searchLower = searchFilter.toLowerCase();
    filteredProducts = filteredProducts.filter(p => 
      p.name.toLowerCase().includes(searchLower) || 
      p.brand.toLowerCase().includes(searchLower) ||
      p.description.toLowerCase().includes(searchLower)
    );
  }

  if (sortBy === 'price-low') {
    filteredProducts.sort((a, b) => (a.discountPrice || a.price) - (b.discountPrice || b.price));
  } else if (sortBy === 'price-high') {
    filteredProducts.sort((a, b) => (b.discountPrice || b.price) - (a.discountPrice || a.price));
  }

  const handleCategoryChange = (categoryId: string | null) => {
    if (categoryId) {
      setSearchParams({ category: categoryId });
    } else {
      setSearchParams({});
    }
    setVisibleCount(24);
  };
  
  const handleLoadMore = () => {
    setVisibleCount(prev => prev + 24);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex flex-col md:flex-row justify-between items-end mb-8  pb-6">
        <div>
          <h1 className="text-4xl font-serif font-bold  mb-2">
            {searchFilter ? `Search: "${searchFilter}"` : categoryFilter ? categories.find(c => c.id === categoryFilter)?.name : 'All Products'}
          </h1>
          <p className="text-[10px] text-[#ffffff]/50 tracking-[0.2em] uppercase">{filteredProducts.length} results</p>
        </div>
        
        <div className="flex items-center gap-4 mt-4 md:mt-0">
          <button 
            className="md:hidden flex items-center gap-2 text-[10px] tracking-widest font-medium uppercase  px-4 py-2 !bg-[#facc15] !text-[#7f1d1d] !border-none font-bold hover:!bg-[#eab308]"
            onClick={() => setIsMobileFiltersOpen(!isMobileFiltersOpen)}
          >
            <Filter size={14} /> Filters
          </button>
          
          <select 
            value={sortBy} 
            onChange={(e) => setSortBy(e.target.value)}
            className="text-[10px]  bg-[#991b1b] text-[#ffffff] py-2 pl-3 pr-8 focus:ring-0 cursor-pointer uppercase tracking-widest font-medium focus: focus:outline-none"
          >
            <option value="featured">Featured</option>
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
          </select>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-12">
        {/* Sidebar Filters */}
        <div className={`md:w-56 shrink-0 ${isMobileFiltersOpen ? 'block' : 'hidden'} md:block`}>
          <div className="sticky top-28">
            <h3 className="text-[10px] tracking-[0.3em] font-semibold text-[#ffffff]/90 uppercase mb-6  pb-2">Categories</h3>
            <ul className="space-y-4 text-xs">
              <li>
                <button 
                  onClick={() => handleCategoryChange(null)}
                  className={`hover:text-[#ffffff] transition-colors tracking-widest uppercase ${!categoryFilter ? 'text-[#ffffff] font-medium' : 'text-[#ffffff]/50'}`}
                >
                  All Products
                </button>
              </li>
              {categories.map(category => (
                <li key={category.id}>
                  <button 
                    onClick={() => handleCategoryChange(category.id)}
                    className={`hover:text-[#ffffff] transition-colors text-left w-full tracking-widest uppercase ${categoryFilter === category.id ? 'text-[#ffffff] font-medium' : 'text-[#ffffff]/50'}`}
                  >
                    {category.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Product Grid */}
        <div className="flex-1">
          {filteredProducts.length > 0 ? (
            <div className="flex flex-col">
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2">
                {filteredProducts.slice(0, visibleCount).map(product => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
              {visibleCount < filteredProducts.length && (
                <div className="mt-12 flex justify-center">
                  <button 
                    onClick={handleLoadMore}
                    className="bg-[#facc15] text-[#7f1d1d] hover:bg-[#eab308] px-8 py-3 font-bold text-xs tracking-widest uppercase transition-colors"
                  >
                    Load More
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-20">
              <p className="text-[#ffffff]/50 text-sm mb-6">No products found in this category.</p>
              <button 
                onClick={() => handleCategoryChange(null)}
                className="text-xs tracking-widest uppercase font-medium  pb-1"
              >
                Clear Filters
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
