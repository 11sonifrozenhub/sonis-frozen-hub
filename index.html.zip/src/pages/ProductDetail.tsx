import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { products } from '../data';
import { useCart } from '../context/CartContext';
import { Minus, Plus, ShoppingCart, ArrowLeft, Star } from 'lucide-react';
import { motion } from 'motion/react';

export function ProductDetail() {
  const { id } = useParams();
  const product = products.find(p => p.id === id);
  const { addToCart } = useCart();
  
  const [quantity, setQuantity] = useState(1);
  const [selectedSize, setSelectedSize] = useState(product?.sizes?.[0] || '');
  const [selectedFlavour, setSelectedFlavour] = useState(product?.flavours?.[0] || '');
  const [reviews, setReviews] = useState(product?.reviews || []);
  const [newReview, setNewReview] = useState({ rating: 5, comment: '', user: '' });

  if (!product) {
    return <div className="text-center py-20">Product not found</div>;
  }

  const handleAddToCart = () => {
    addToCart(product, quantity, selectedSize, selectedFlavour);
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReview.comment.trim() || !newReview.user.trim()) return;

    const review = {
      id: Date.now().toString(),
      user: newReview.user,
      rating: newReview.rating,
      comment: newReview.comment,
      date: new Date().toISOString().split('T')[0]
    };

    const updatedReviews = [review, ...reviews];
    setReviews(updatedReviews);
    product.reviews = updatedReviews;
    
    if (updatedReviews.length > 0) {
      const newRating = updatedReviews.reduce((acc, r) => acc + r.rating, 0) / updatedReviews.length;
      product.rating = Number(newRating.toFixed(1));
    }

    setNewReview({ rating: 5, comment: '', user: '' });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 flex-1">
      <Link to="/products" className="inline-flex items-center gap-2 text-[10px] text-[#ffffff]/50 hover:text-[#ffffff] transition-colors mb-8 uppercase tracking-widest font-bold">
        <ArrowLeft size={14} /> Back to Products
      </Link>

      <div className="grid md:grid-cols-2 gap-12 lg:gap-20">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-[#7f1d1d]  p-12 relative flex items-center justify-center aspect-square overflow-hidden group"
        >
          <img src={product.image} alt={product.name} className="w-full h-full object-contain opacity-100 transition-opacity duration-700" />
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex flex-col justify-center"
        >
          <div className="text-[10px] font-bold uppercase tracking-[0.3em] text-[#ffffff]/50 mb-4">{product.brand}</div>
          <h1 className="text-3xl md:text-5xl font-serif font-bold  mb-6 leading-tight">{product.name}</h1>
          
          <div className="flex items-center gap-4 mb-8">
            <div className="flex items-center gap-1 opacity-70">
              {[...Array(5)].map((_, i) => (
                <Star key={i} size={14} className={i < Math.floor(product.rating) ? "fill-white text-[#ffffff]" : "text-[#ffffff]/20"} />
              ))}
            </div>
            <span className="text-[10px] text-[#ffffff]/50 tracking-widest uppercase">{product.rating} Rating</span>
          </div>

          <div className="flex items-baseline gap-4 mb-8  pb-8">
            {product.discountPrice ? (
              <>
                <span className="text-3xl font-bold tracking-wider">₹{product.discountPrice}</span>
                <span className="text-xl text-[#ffffff]/40 line-through tracking-wider">₹{product.price}</span>
              </>
            ) : (
              <span className="text-3xl font-bold tracking-wider">₹{product.price}</span>
            )}
          </div>

          <p className="text-[#ffffff]/70 mb-8 leading-relaxed text-sm">
            {product.description}
          </p>

          {product.flavours && (
            <div className="mb-8">
              <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] mb-4 text-[#ffffff]/50">Flavour</h3>
              <div className="flex flex-wrap gap-3">
                {product.flavours.map(flavour => (
                  <button
                    key={flavour}
                    onClick={() => setSelectedFlavour(flavour)}
                    className={`px-6 py-2 text-xs tracking-widest border font-medium transition-colors uppercase ${
                      selectedFlavour === flavour 
                        ? ' bg-[#7f1d1d] text-[#ffffff]' 
                        : ' text-[#ffffff]/70 hover:'
                    }`}
                  >
                    {flavour}
                  </button>
                ))}
              </div>
            </div>
          )}

          {product.sizes && (
            <div className="mb-10">
              <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] mb-4 text-[#ffffff]/50">Size</h3>
              <div className="flex flex-wrap gap-3">
                {product.sizes.map(size => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`px-6 py-2 text-xs tracking-widest border font-medium transition-colors uppercase ${
                      selectedSize === size 
                        ? ' bg-[#7f1d1d] text-[#ffffff]' 
                        : ' text-[#ffffff]/70 hover:'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="flex flex-col sm:flex-row gap-6 mb-10">
            <div className="flex items-center ">
              <button 
                onClick={() => setQuantity(q => Math.max(1, q - 1))}
                className="p-4 text-[#ffffff]/50 hover:text-[#ffffff] transition-colors"
              >
                <Minus size={14} />
              </button>
              <span className="w-12 text-center font-bold text-lg">{quantity}</span>
              <button 
                onClick={() => setQuantity(q => q + 1)}
                className="p-4 text-[#ffffff]/50 hover:text-[#ffffff] transition-colors"
              >
                <Plus size={14} />
              </button>
            </div>
            
            <button 
              onClick={handleAddToCart}
              className="flex-1  bg-[#7f1d1d] text-[#ffffff] flex items-center justify-center gap-3 py-4 px-8 text-xs font-bold uppercase tracking-[0.2em] hover:bg-transparent hover:text-[#ffffff] transition-colors !bg-[#facc15] !text-[#7f1d1d] !border-none font-bold hover:!bg-[#eab308]"
            >
              <ShoppingCart size={16} />
              Add to Cart
            </button>
          </div>

          <div className=" pt-8">
            <ul className="space-y-4 text-[10px] tracking-widest uppercase">
              <li className="flex justify-between /5 pb-2">
                <span className="text-[#ffffff]/50">Availability:</span>
                <span className={product.inStock ? 'text-[#ffffff]' : 'text-red-500'}>
                  {product.inStock ? 'In Stock' : 'Out of Stock'}
                </span>
              </li>
              <li className="flex justify-between pb-2">
                <span className="text-[#ffffff]/50">Category:</span>
                <span className="text-[#ffffff]">{product.category.replace('-', ' ')}</span>
              </li>
            </ul>
          </div>
        </motion.div>
      </div>

      {/* Reviews Section */}
      <div className="mt-24  pt-12">
        <h2 className="text-2xl font-serif font-bold mb-8">Customer Reviews</h2>
        
        <div className="grid md:grid-cols-2 gap-12">
          {/* Write a Review */}
          <div>
            <h3 className="text-sm font-bold uppercase tracking-widest mb-6  pb-2">Write a Review</h3>
            <form onSubmit={handleReviewSubmit} className="space-y-6">
              <div>
                <label className="block text-[10px] tracking-widest uppercase mb-2 text-[#ffffff]/70">Your Name</label>
                <input 
                  type="text" 
                  value={newReview.user}
                  onChange={(e) => setNewReview({...newReview, user: e.target.value})}
                  required
                  className="w-full bg-[#991b1b]  py-2 px-4 text-sm focus:outline-none focus: text-[#ffffff] placeholder-white/50"
                  placeholder="Enter your name"
                />
              </div>
              
              <div>
                <label className="block text-[10px] tracking-widest uppercase mb-2 text-[#ffffff]/70">Rating</label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setNewReview({...newReview, rating: star})}
                      className="focus:outline-none bg-transparent !bg-transparent !border-none !p-0"
                    >
                      <Star size={20} className={star <= newReview.rating ? "fill-white text-[#facc15]" : "text-[#ffffff]/20"} />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-[10px] tracking-widest uppercase mb-2 text-[#ffffff]/70">Your Review</label>
                <textarea 
                  value={newReview.comment}
                  onChange={(e) => setNewReview({...newReview, comment: e.target.value})}
                  required
                  rows={4}
                  className="w-full bg-[#991b1b]  py-2 px-4 text-sm focus:outline-none focus: text-[#ffffff] placeholder-white/50 resize-none"
                  placeholder="Share your experience with this product..."
                />
              </div>

              <button type="submit" className="w-full bg-[#facc15] text-[#7f1d1d] hover:bg-[#eab308] border-none font-bold py-3 text-[10px] uppercase tracking-widest flex justify-center items-center gap-2 transition-colors">
                Submit Review
              </button>
            </form>
          </div>

          {/* Review List */}
          <div>
            <h3 className="text-sm font-bold uppercase tracking-widest mb-6  pb-2">
              Reviews ({reviews.length})
            </h3>
            
            <div className="space-y-6 max-h-[500px] overflow-y-auto pr-2">
              {reviews.length > 0 ? (
                reviews.map(review => (
                  <div key={review.id} className="bg-[#991b1b] p-6 ">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <div className="font-bold text-sm tracking-wide mb-1">{review.user}</div>
                        <div className="text-[10px] tracking-widest text-[#ffffff]/50">{review.date}</div>
                      </div>
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} size={12} className={i < review.rating ? "fill-white text-[#facc15]" : "text-[#ffffff]/20"} />
                        ))}
                      </div>
                    </div>
                    <p className="text-sm leading-relaxed text-[#ffffff]/80">
                      {review.comment}
                    </p>
                  </div>
                ))
              ) : (
                <div className="text-sm text-[#ffffff]/50 italic">
                  No reviews yet. Be the first to review this product!
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
