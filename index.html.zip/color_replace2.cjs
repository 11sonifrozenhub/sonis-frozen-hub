const fs = require('fs');
const path = require('path');

const walk = (dir) => {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach((file) => {
    file = path.join(dir, file);
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) {
      results = results.concat(walk(file));
    } else if (file.endsWith('.tsx')) {
      results.push(file);
    }
  });
  return results;
};

const files = walk('./src');

files.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  
  // Replace colors
  content = content.replace(/bg-yellow-400/g, 'bg-[#5C3A21]');
  content = content.replace(/bg-yellow-500/g, 'bg-[#70492E]');
  content = content.replace(/bg-white/g, 'bg-[#1A2F24]');
  content = content.replace(/bg-yellow-50/g, 'bg-[#2A4535]');
  
  content = content.replace(/text-black/g, 'text-[#F0E6D2]');
  content = content.replace(/text-white/g, 'text-[#F0E6D2]'); // fallback
  content = content.replace(/bg-black/g, 'bg-[#5C3A21]'); 
  
  // Replace borders
  content = content.replace(/border-yellow-200/g, 'border-[#3A5A45]');
  content = content.replace(/border-yellow-300/g, 'border-[#4A6E55]');
  content = content.replace(/border-yellow-400/g, 'border-[#5C3A21]');
  content = content.replace(/border-yellow-500/g, 'border-[#70492E]');
  
  // Add everywhere animation classes to common interactive elements (buttons, links)
  // Replaced by global CSS to be safer and truly "everywhere"
  
  fs.writeFileSync(file, content);
});

console.log('Done replacing colors for brown/green theme');
