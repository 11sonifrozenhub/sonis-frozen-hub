const fs = require('fs');
const path = require('path');

const walk = (dir) => {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach((file) => {
    file = path.join(dir, file);
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) {
      results = results.concat(walk(file));
    } else if (file.endsWith('.tsx')) {
      results.push(file);
    }
  });
  return results;
};

const files = walk('./src');

files.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  
  // Remove mix-blend-screen and fix opacity
  content = content.replace(/mix-blend-screen\s*/g, '');
  content = content.replace(/opacity-80 group-hover:opacity-100/g, 'opacity-100');
  content = content.replace(/opacity-50 group-hover:opacity-70/g, 'opacity-100 group-hover:opacity-90');
  
  fs.writeFileSync(file, content);
});

console.log('Fixed images');
