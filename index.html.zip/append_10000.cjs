const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, 'src', 'data.ts');
let content = fs.readFileSync(dataPath, 'utf8');

const codeToAppend = `
const brands = ["Nestlé", "Lindt", "Ferrero", "Pringles", "Lotte", "Haribo", "Milka", "Toblerone", "Kinder", "Ritter Sport"];
const categories = ["imported-snacks", "imported-drinks", "frozen-products", "ice-cream-desserts", "grocery", "special-collections"];

for (let i = 1; i <= 10000; i++) {
  const isNewArrival = Math.random() > 0.5;
  const hasDiscount = Math.random() > 0.7;
  const price = Math.floor(Math.random() * 500) + 100;
  const discountPrice = hasDiscount ? price - Math.floor(Math.random() * 50) - 10 : undefined;
  
  products.push({
    id: \`bulk-product-\${i}\`,
    name: \`Premium Bulk Product \${i}\`,
    brand: brands[i % brands.length],
    description: 'This is a bulk generated premium product for testing extreme list performance.',
    price,
    discountPrice,
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: categories[i % categories.length],
    isNewArrival,
    flavours: i % 3 === 0 ? ['Original', 'Spicy', 'Sweet'] : undefined,
    sizes: i % 4 === 0 ? ['Small', 'Medium', 'Large'] : undefined
  });
}
`;

fs.appendFileSync(dataPath, codeToAppend);
console.log('Appended bulk generation code to data.ts');
