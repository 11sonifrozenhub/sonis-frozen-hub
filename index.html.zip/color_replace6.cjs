const fs = require('fs');
const path = require('path');

const walk = (dir) => {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach((file) => {
    file = path.join(dir, file);
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) {
      results = results.concat(walk(file));
    } else if (file.endsWith('.tsx') || file.endsWith('.css')) {
      results.push(file);
    }
  });
  return results;
};

const files = walk('./src');

files.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  
  // Make all buttons yellow
  content = content.replace(/className="([^"]*)button([^"]*)"/gi, (match, p1, p2) => {
    return `className="w-full bg-[#facc15] text-[#7f1d1d] hover:bg-[#eab308] border-none font-bold py-3 text-[10px] uppercase tracking-widest flex justify-center items-center gap-2 transition-colors"`;
  });
  
  // Actually, some buttons might not have 'button' in their class, let's just target the button tag entirely if it has a class.
  content = content.replace(/<button[^>]*className="([^"]*)"[^>]*>/gi, (match, classStr) => {
    if (classStr.includes('bg-transparent') && !classStr.includes('text-[#fef08a]')) {
       return match; 
    }
    // We want to turn them to yellow buttons, but keep some structural classes.
    return match.replace(classStr, classStr + ' !bg-[#facc15] !text-[#7f1d1d] !border-none font-bold hover:!bg-[#eab308]');
  });
  
  fs.writeFileSync(file, content);
});

console.log('Done replacing buttons to yellow');
