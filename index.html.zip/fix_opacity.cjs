const fs = require('fs');
const path = require('path');

const filesToFix = [
  './src/pages/Cart.tsx',
  './src/pages/Checkout.tsx',
];

filesToFix.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  content = content.replace(/opacity-80/g, 'opacity-100');
  fs.writeFileSync(file, content);
});

console.log('Fixed opacity');
