const fs = require('fs');
const path = require('path');

const filesToFix = [
  './src/pages/ProductDetail.tsx',
  './src/pages/Cart.tsx',
  './src/pages/Checkout.tsx',
  './src/components/ProductCard.tsx'
];

filesToFix.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  content = content.replace(/object-cover/g, 'object-contain');
  fs.writeFileSync(file, content);
});

console.log('Fixed object-fit');
