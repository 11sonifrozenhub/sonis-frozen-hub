const fs = require('fs');
const path = require('path');

const dataPath = path.join(__dirname, 'src', 'data.ts');
let content = fs.readFileSync(dataPath, 'utf8');

const newProducts = [];
const brands = ["Nestlé", "Lindt", "Ferrero", "Pringles", "Lotte", "Haribo", "Milka", "Toblerone", "Kinder", "Ritter Sport"];
const categories = [
  "imported-snacks", "imported-drinks", "frozen-products", 
  "ice-cream-desserts", "grocery", "special-collections"
];

for (let i = 1; i <= 50; i++) {
  const isNewArrival = Math.random() > 0.5;
  const hasDiscount = Math.random() > 0.7;
  const price = Math.floor(Math.random() * 500) + 100;
  const discountPrice = hasDiscount ? price - Math.floor(Math.random() * 50) - 10 : undefined;
  
  newProducts.push(`
  {
    id: 'gen-product-${i}',
    name: 'Premium Imported Product ${i}',
    brand: '${brands[i % brands.length]}',
    description: 'This is a beautifully crafted premium imported product, loved by many all over the world. A great addition to your collection.',
    price: ${price},
    ${discountPrice ? `discountPrice: ${discountPrice},` : ''}
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=500&q=80',
    category: '${categories[i % categories.length]}',
    ${isNewArrival ? `isNewArrival: true,` : ''}
    ${i % 3 === 0 ? `flavours: ['Original', 'Spicy', 'Sweet'],` : ''}
    ${i % 4 === 0 ? `sizes: ['Small', 'Medium', 'Large'],` : ''}
  }`);
}

// Insert before the last ];
const insertionPoint = content.lastIndexOf('];');
if (insertionPoint !== -1) {
  content = content.slice(0, insertionPoint) + ',' + newProducts.join(',') + '\n' + content.slice(insertionPoint);
  fs.writeFileSync(dataPath, content);
  console.log('Added 50 products');
} else {
  console.log('Could not find insertion point');
}
