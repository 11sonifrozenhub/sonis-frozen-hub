const fs = require('fs');
const path = require('path');

const walk = (dir) => {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach((file) => {
    file = path.join(dir, file);
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) {
      results = results.concat(walk(file));
    } else if (file.endsWith('.tsx') || file.endsWith('.css')) {
      results.push(file);
    }
  });
  return results;
};

const files = walk('./src');

files.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  
  // Backgrounds back to red
  content = content.replace(/#4f4035/gi, '#7f1d1d');
  content = content.replace(/#6e5c4f/gi, '#991b1b');
  content = content.replace(/#8c7868/gi, '#b91c1c');
  
  // To make all buttons yellow:
  // Instead of complex CSS replacements, I'll update common button class fragments.
  content = content.replace(/hover:bg-\[#7f1d1d\] hover:text-\[#fef08a\]/g, 'bg-[#facc15] text-[#7f1d1d] hover:bg-[#eab308] border-none font-bold');
  content = content.replace(/border border-\[#ca8a04\] py-2\.5 text-\[10px\]/g, 'bg-[#facc15] text-[#7f1d1d] font-bold border-none py-2.5 text-[10px]');
  content = content.replace(/border border-\[#eab308\] px-4 py-2/g, 'bg-[#facc15] text-[#7f1d1d] border-none px-4 py-2 font-bold');
  
  fs.writeFileSync(file, content);
});

console.log('Done');
