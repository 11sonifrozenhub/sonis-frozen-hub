const fs = require('fs');
const path = require('path');

const walk = (dir) => {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach((file) => {
    file = path.join(dir, file);
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) {
      results = results.concat(walk(file));
    } else if (file.endsWith('.tsx')) {
      results.push(file);
    }
  });
  return results;
};

const files = walk('./src');

files.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  
  // Replace colors
  content = content.replace(/bg-black/g, 'bg-yellow-400');
  content = content.replace(/text-white/g, 'text-black');
  content = content.replace(/bg-zinc-900/g, 'bg-white');
  content = content.replace(/bg-zinc-800/g, 'bg-yellow-50');
  
  // Replace borders
  content = content.replace(/border-white\/10/g, 'border-yellow-200');
  content = content.replace(/border-white\/20/g, 'border-yellow-300');
  content = content.replace(/border-white\/30/g, 'border-yellow-400');
  content = content.replace(/border-white\/40/g, 'border-yellow-500');
  content = content.replace(/border-white\/50/g, 'border-yellow-500');
  content = content.replace(/border-white/g, 'border-yellow-400');
  
  // Replace text opacities
  content = content.replace(/text-white\/40/g, 'text-black/40');
  content = content.replace(/text-white\/50/g, 'text-black/50');
  content = content.replace(/text-white\/60/g, 'text-black/60');
  content = content.replace(/text-white\/70/g, 'text-black/70');
  content = content.replace(/text-white\/80/g, 'text-black/80');
  content = content.replace(/text-white\/90/g, 'text-black/90');
  
  // Replace fonts
  content = content.replace(/font-light/g, 'font-bold');
  content = content.replace(/italic/g, '');
  
  fs.writeFileSync(file, content);
});

console.log('Done replacing colors');
