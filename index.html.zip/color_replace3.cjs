const fs = require('fs');
const path = require('path');

const walk = (dir) => {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach((file) => {
    file = path.join(dir, file);
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) {
      results = results.concat(walk(file));
    } else if (file.endsWith('.tsx') || file.endsWith('.css')) {
      results.push(file);
    }
  });
  return results;
};

const files = walk('./src');

files.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  
  // Replace colors
  content = content.replace(/#1A2F24/gi, '#7f1d1d');
  content = content.replace(/#5C3A21/gi, '#991b1b');
  content = content.replace(/#2A4535/gi, '#b91c1c');
  content = content.replace(/#70492E/gi, '#eab308');
  
  content = content.replace(/#F0E6D2/gi, '#fef08a');
  
  // Replace borders
  content = content.replace(/#3A5A45/gi, '#facc15');
  content = content.replace(/#4A6E55/gi, '#ca8a04');
  
  fs.writeFileSync(file, content);
});

console.log('Done replacing colors for red/yellow theme');
