const fs = require('fs');
const path = require('path');

const walk = (dir) => {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach((file) => {
    file = path.join(dir, file);
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) {
      results = results.concat(walk(file));
    } else if (file.endsWith('.tsx') || file.endsWith('.css')) {
      results.push(file);
    }
  });
  return results;
};

const files = walk('./src');

files.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  
  // Replace reds with mule (brownish-grey)
  content = content.replace(/#7f1d1d/gi, '#4f4035');
  content = content.replace(/#991b1b/gi, '#6e5c4f');
  content = content.replace(/#b91c1c/gi, '#8c7868');
  
  fs.writeFileSync(file, content);
});

console.log('Done replacing red with mule color');
